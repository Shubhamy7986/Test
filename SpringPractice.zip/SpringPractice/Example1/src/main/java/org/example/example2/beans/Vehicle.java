package org.example.example2.beans;

public class Vehicle {

    public String type;

    public Vehicle() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
