package org.example.example8.service;

public interface Speaker {

    public String makeSound();
}
