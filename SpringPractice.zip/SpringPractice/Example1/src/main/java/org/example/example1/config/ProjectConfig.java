package org.example.example1.config;

import org.example.example1.beans.Vehicle;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProjectConfig {

    @Bean
    public Vehicle getVehicle() {
        Vehicle vehicle = new Vehicle();
        vehicle.setType("Audi 8");
        return vehicle;
    }
}
