package org.example.example8.beans;

import org.example.example8.service.VehicelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component(value = "vehicleBean")
public class Vehicle {

    public String type;
    private final VehicelService vehicelService;

    @Autowired
    public Vehicle(VehicelService vehicelService) {
        this.vehicelService = vehicelService;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public VehicelService getVehicelService() {
        return vehicelService;
    }

    @PostConstruct
    public void postConstruct() {
        this.type ="Honda";
    }
}
