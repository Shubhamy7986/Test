package org.example.example7;

import org.example.example7.beans.Person;
import org.example.example7.beans.Vehicle;
import org.example.example7.config.ProjectConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

    public static void main(String[] args) {

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProjectConfig.class);
        Person person = context.getBean(Person.class);
        Vehicle vehicle = context.getBean("vehicle3",Vehicle.class);

        System.out.println("Vehicle bean "+vehicle.getType());
        System.out.println("Person bean "+person.getName()+" - "+person.getVehicle().getType());

    }
}
