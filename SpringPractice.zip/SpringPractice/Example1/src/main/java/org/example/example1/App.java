package org.example.example1;

import org.example.example1.beans.Vehicle;
import org.example.example1.config.ProjectConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

    public static void main(String[] args) {

        Vehicle veh = new Vehicle();
        veh.setType("BMW");
        System.out.println("Created object using new "+veh.getType());

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProjectConfig.class);
        Vehicle vehicle = context.getBean(Vehicle.class);
        System.out.println("Fetched object from spring context/IOC container "+vehicle.getType());
    }
}
