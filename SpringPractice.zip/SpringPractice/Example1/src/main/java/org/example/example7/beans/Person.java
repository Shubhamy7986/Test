package org.example.example7.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class Person {

    //@Autowiring multiple beans of same class type
    //1. Fetch bean of same name as parameter name declared in constructor
    //2. Fetch @Primary bean if parameter name does not match
    //3. Fetch bean from spring context defined in @Qualifier annotation

    private String name;

    private final Vehicle vehicle;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    @Autowired()
    public Person(@Qualifier("vehicle3") Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    @PostConstruct
    public void postConstruct() {
        this.name="Paul";
    }
}
