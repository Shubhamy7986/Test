package org.example.example5;

import org.example.example5.beans.Person;
import org.example.example5.beans.Vehicle;
import org.example.example5.config.ProjectConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

    public static void main(String[] args) {
       //Autowiring bean using method call, method parameters

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProjectConfig.class);
        Person person = context.getBean(Person.class);
        Vehicle vehicle = context.getBean(Vehicle.class);
        System.out.println("Fetched vehicle bean from spring context/IOC container : "+vehicle.getType());
        System.out.println("Fetched person bean from spring context/IOC Container where vehicle " +
                "is autowired in person using method call or method parameters : person name : "+person.getName()+" vehicle name :  "+person.getVehicle().getType());
    }
}
