package org.example.example8.service;

public interface Tyres {

    public String rotate();
}
