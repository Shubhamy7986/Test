package org.example.example6;

import org.example.example6.beans.Person;
import org.example.example6.beans.Vehicle;
import org.example.example6.config.ProjectConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

    public static void main(String[] args) {
       //Autowiring using @Autowired annotation

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProjectConfig.class);
        Person person = context.getBean(Person.class);
        Vehicle vehicle = context.getBean(Vehicle.class);
        System.out.println("Fetched vehicle bean from spring context/IOC container : "+vehicle.getType());
        System.out.println("Fetched person bean from spring context/IOC Container where vehicle " +
                "is autowired in person using constructor or setter injection : person name : "+person.getName()+" vehicle name :  "+person.getVehicle().getType());
    }
}
