package org.example.example8.service;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
public class SonySpeakers implements Speaker{

    @Override
    public String makeSound() {
        return "SonySpeakers";
    }

}
