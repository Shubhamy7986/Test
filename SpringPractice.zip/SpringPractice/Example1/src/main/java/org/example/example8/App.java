package org.example.example8;

import org.example.example8.beans.Person;
import org.example.example8.beans.Vehicle;
import org.example.example8.config.ProjectConfig;
import org.example.example8.service.VehicelService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

    public static void main(String[] args) {

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProjectConfig.class);
        Person person = context.getBean(Person.class);
        VehicelService vehicelService = context.getBean(VehicelService.class);


        System.out.println("Person bean "+person.getName()+" - "+person.getVehicle().getType()+" - "+vehicelService.getSpeaker().makeSound()+" - "+vehicelService.getTyres().rotate());

    }
}
