package org.example.example3;

import org.example.example3.beans.Vehicle;
import org.example.example3.config.ProjectConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

    public static void main(String[] args) {
       //@Component,@ComponentScan,@PostConstruct,@PreDestroy

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProjectConfig.class);
        Vehicle vehicle1 = context.getBean(Vehicle.class);vehicle1.setType("Honda");
        context.close();
        System.out.println("Fetched vehicle1 bean from spring context/IOC container :"+vehicle1.getType());
    }
}
