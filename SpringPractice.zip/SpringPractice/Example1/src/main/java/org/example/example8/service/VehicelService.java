package org.example.example8.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class VehicelService {

    @Autowired
    private Speaker speaker;
    private Tyres tyres;

    public Speaker getSpeaker() {
        return speaker;
    }

    public void setSpeaker(Speaker speaker) {
        this.speaker = speaker;
    }

    public Tyres getTyres() {
        return tyres;
    }

    @Autowired
    public void setTyres(Tyres tyres) {
        this.tyres = tyres;
    }

    @Autowired
    public void playSound() {
        String music = speaker.makeSound();
        System.out.println(music);
    }


    public void moveVehicle() {
        String tyresType = tyres.rotate();
        System.out.println(tyresType);
    }
}
