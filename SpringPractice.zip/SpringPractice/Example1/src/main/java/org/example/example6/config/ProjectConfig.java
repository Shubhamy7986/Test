package org.example.example6.config;

import org.example.example6.beans.Person;
import org.example.example6.beans.Vehicle;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "org.example.example6.beans")
public class ProjectConfig {

}
