package org.example.example4;

import org.example.example4.beans.Vehicle;
import org.example.example4.config.ProjectConfig;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Random;
import java.util.function.Supplier;

public class App {

    public static void main(String[] args) {
       //registerBean method introduced in Spring 5 to create new instances of an object
       //and add them in Spring context based on a programming condition

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProjectConfig.class);

        Vehicle volkswagon = new Vehicle();
        volkswagon.setType("volkswagon");

        Supplier<Vehicle> volkswagonSupplier = () -> volkswagon;

        Supplier<Vehicle> audiSupplier = () -> {
            Vehicle audi = new Vehicle();
            audi.setType("audi");
            return audi;
        };

        Random random = new Random();
        int randomNumber = random.nextInt(10);

        System.out.println(randomNumber);

        if(randomNumber % 2 ==0) {
            context.registerBean("volkswagon",Vehicle.class,volkswagonSupplier);
        }else {
            context.registerBean("audi",Vehicle.class,audiSupplier);
        }


        Vehicle volksVehicle = null;
        Vehicle audiVehicle = null;

        try{
            volksVehicle = context.getBean("volkswagon",Vehicle.class);
        }catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {
            System.out.println("Error while creating volkswagon bean");
        }

        try{
            audiVehicle = context.getBean("audi",Vehicle.class);
        }catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {
            System.out.println("Error while creating audi bean");
        }

        if(volksVehicle != null) {
            System.out.println("Fetching vehicle from spring context : "+volksVehicle.getType());
        }else {
            System.out.println("Fetching vehicle from spring context : "+audiVehicle.getType());
        }

    }
}
