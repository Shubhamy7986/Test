package org.example.example5.config;

import org.example.example5.beans.Vehicle;
import org.example.example5.beans.Person;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProjectConfig {

    @Bean
    public Vehicle vehicle() {
        Vehicle vehicle = new Vehicle();
        vehicle.setType("Honda");
        return vehicle;
    }

    //Using method call
    /*@Bean
    public Person person() {
        Person person = new Person();
        person.setName("Paul");
        person.setVehicle(vehicle());
        return person;
    }*/

    //Using method parameters
    @Bean
    public Person person(Vehicle vehicle) {
        Person person = new Person();
        person.setName("Paul");
        person.setVehicle(vehicle);
        return person;
    }

}
