package org.example.example2;

import org.example.example2.beans.Vehicle;
import org.example.example2.config.ProjectConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

    public static void main(String[] args) {

        //NoUniqueBeanDefinition
        /* When multiple objects of same type are created and called then NoUniqueBeanDefinition Occurs
        *  To avoid such exception use getBean(methodname,class) or add name or value in @Bean annotation
        * */

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProjectConfig.class);
        Vehicle vehicle1 = context.getBean("getVehicle1",Vehicle.class);
        Vehicle veh1 = context.getBean("vehicle1",Vehicle.class);
        Vehicle vehicle2 = context.getBean("vehicle2",Vehicle.class);
        Vehicle vehicle3 = context.getBean("vehicle3",Vehicle.class);
        Vehicle vehicle4 = context.getBean(Vehicle.class);


        System.out.println("Fetched object from spring context/IOC container using methodname : "+vehicle1.getType());
        System.out.println("Fetched object from spring context/IOC container using bean name : "+veh1.getType());
        System.out.println("Fetched object from spring context/IOC container using bean value : "+vehicle2.getType());
        System.out.println("Fetched object from spring context/IOC container using empty attribute : "+vehicle3.getType());
        System.out.println("Fetched object from spring context/IOC container using primary annotation : "+vehicle4.getType());


    }
}
