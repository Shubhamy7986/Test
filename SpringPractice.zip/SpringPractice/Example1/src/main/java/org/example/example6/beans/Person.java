package org.example.example6.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class Person {

    private String name;

    private final Vehicle vehicle;

    //Autowired on class fields
    /*@Autowired
    private Vehicle vehicle;*/

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    //Autowired on setter method
    /*@Autowired(required = false)
    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }*/

    //Autowired using constructor - For spring 4.3 if only one constructor is present
    // then there is no need to add @Autowired annotation
    @Autowired()
    public Person(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    @PostConstruct
    public void postConstruct() {
        this.name="Paul";
    }
}
