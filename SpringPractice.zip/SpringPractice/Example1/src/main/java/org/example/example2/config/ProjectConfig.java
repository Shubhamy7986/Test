package org.example.example2.config;

import org.example.example2.beans.Vehicle;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class ProjectConfig {

    @Bean()
    public Vehicle getVehicle1() {
        Vehicle vehicle1 = new Vehicle();
        vehicle1.setType("Audi 8");
        return vehicle1;
    }

    @Bean(name="vehicle1")
    public Vehicle getVeh1() {
        Vehicle vehicle1 = new Vehicle();
        vehicle1.setType("Audi 8");
        return vehicle1;
    }

    @Bean(value="vehicle2")
    public Vehicle getVehicle2() {
        Vehicle vehicle2 = new Vehicle();
        vehicle2.setType("Honda");
        return vehicle2;
    }

    @Bean("vehicle3")
    public Vehicle getVehicle3() {
        Vehicle vehicle3 = new Vehicle();
        vehicle3.setType("BMW");
        return vehicle3;
    }

    @Bean()
    @Primary
    public Vehicle getVehicle4() {
        Vehicle vehicle4 = new Vehicle();
        vehicle4.setType("Mahindra");
        return vehicle4;
    }
}
