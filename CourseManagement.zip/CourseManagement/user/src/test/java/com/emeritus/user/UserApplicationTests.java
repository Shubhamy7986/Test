package com.emeritus.user;

import com.emeritus.user.model.User;
import com.emeritus.user.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
class UserApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;


    @Test
    public void givenUserObject_whenCreateUser_thenReturnSavedUser() throws Exception {

        // given - precondition or setup/
        User user = User.builder()
                .userName("TestName")
                .userEmail("testname@gmail.com")
                .userType("Student")
                .build();

        given(userService.addUser(any(User.class)))
                .willAnswer((invocation) -> invocation.getArgument(0));

        // when - action or behaviour that we are going test
        ResultActions response = mockMvc.perform(post("/user")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(user)));

        // then - verify the result or output using assert statements
        response.andDo(print()).
                andExpect(status().isOk())
                .andExpect(jsonPath("$.userName",
                        is(user.getUserName())))
                .andExpect(jsonPath("$.userEmail",
                        is(user.getUserEmail())))
                .andExpect(jsonPath("$.userType",
                        is(user.getUserType())));

    }


    @Test
    public void givenListOfUsers_whenGetAllUsers_thenReturnUsersList() throws Exception {
        // given - precondition or setup
        List<User> listofUsers = new ArrayList<>();
        listofUsers.add(User.builder().userId(1).userName("TestName").userEmail("testname@gmail.com").userType("Student").build());
        listofUsers.add(User.builder().userId(2).userName("TestName1").userEmail("testname1@gmail.com").userType("Student").build());
        given(userService.getAllUsers()).willReturn(listofUsers);

        // when -  action or the behaviour that we are going test
        ResultActions response = mockMvc.perform(get("/users"));

        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print())
                .andExpect(jsonPath("$.size()",
                        is(listofUsers.size())));

    }


    @Test
    public void givenUserId_whenGetUserById_thenReturnUserObject() throws Exception {
        // given - precondition or setup
        Integer userId = 1;
        User user = User.builder()
                .userName("TestUser")
                .userEmail("testuser@gmail.com")
                .userType("System_Admin")
                .build();
        given(userService.getUser(userId)).willReturn(Optional.of(user));

        // when -  action or the behaviour that we are going test
        ResultActions response = mockMvc.perform(get("/user/{userId}", userId));

        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print())
                .andExpect(jsonPath("$.userName", is(user.getUserName())))
                .andExpect(jsonPath("$.userEmail", is(user.getUserEmail())))
                .andExpect(jsonPath("$.userType", is(user.getUserType())));

    }


    @Test
    public void givenUpdatedUser_whenUpdateUser_thenReturnUpdatedUserObject() throws Exception {
        // given - precondition or setup
        Integer userId = 1;
        User savedUser = User.builder()
                .userId(1)
                .userName("TestUser")
                .userEmail("testuser@gmail.com")
                .userType("System_Admin")
                .build();

        User updatedUser = User.builder()
                .userId(1)
                .userName("TestUser")
                .userEmail("testuser@gmail.com")
                .userType("Instructor")
                .build();

        given(userService.getUser(userId)).willReturn(Optional.of(savedUser));
        given(userService.updateUser(any(User.class)))
                .willAnswer((invocation) -> invocation.getArgument(0));

        // when -  action or the behaviour that we are going test
        ResultActions response = mockMvc.perform(put("/user")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedUser)));


        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print())
                .andExpect(jsonPath("$.userName", is(updatedUser.getUserName())))
                .andExpect(jsonPath("$.userEmail", is(updatedUser.getUserEmail())))
                .andExpect(jsonPath("$.userType", is(updatedUser.getUserType())));
    }


    @Test
    public void givenUserId_whenDeleteUser_thenReturn200() throws Exception {
        // given - precondition or setup
        Integer userId = 1;
        willDoNothing().given(userService).deleteUser(userId);

        // when -  action or the behaviour that we are going test
        ResultActions response = mockMvc.perform(delete("/user/{userId}", userId));

        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print());
    }


}
