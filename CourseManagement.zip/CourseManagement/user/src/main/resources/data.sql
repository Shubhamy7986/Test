insert into users(user_name,user_email,user_type) values('Vikas','vikas@gmail.com','System_Admin');
insert into users(user_name,user_email,user_type) values('Ritesh','ritesh@gmail.com','Instructor');
insert into users(user_name,user_email,user_type) values('Sanyam','sanyam@gmail.com','Student');
