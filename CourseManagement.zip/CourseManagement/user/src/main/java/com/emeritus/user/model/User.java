package com.emeritus.user.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {


    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "user_name", nullable = false)
    @NotBlank(message = "User name must not be blank")
    private String userName;

    @Column(name = "user_email", nullable = false)
    @NotBlank(message = "User email must not be blank")
    @Email(message = "Please provide a vaild email address ")
    private String userEmail;

    @Column(name = "user_type", nullable = false)
    @NotBlank(message = "User type must not be blank")
    private String userType;

}
