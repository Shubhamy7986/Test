package com.emeritus.user.model;

public enum UserType {
    System_Admin, Instructor, Student
}
