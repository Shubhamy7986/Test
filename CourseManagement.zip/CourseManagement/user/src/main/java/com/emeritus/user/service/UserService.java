package com.emeritus.user.service;

import com.emeritus.user.exception.UserException;
import com.emeritus.user.model.User;
import com.emeritus.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    public List<User> getAllUsers() {
        return (List<User>) userRepository.findAll();
    }

    public Optional<User> getUser(Integer userId) {
        return userRepository.findById(userId);
    }

    public User getUserByEmail(String userEmail) {
        return userRepository.findByUserEmail(userEmail);
    }

    public List<User> getAllUsersOfTypeStudent(Integer userId) {
        Optional<User> user = userRepository.findById(userId);
        if (user.isPresent() && user.get().getUserType().equals("System_Admin")) {
            return userRepository.findByUserType("Student");
        } else {
            throw new UserException("User do not have required permission");
        }
    }

    public User addUser(User user) {
        if (!userRepository.existsByUserEmail(user.getUserEmail())) {
            return userRepository.save(user);
        } else {
            throw new UserException("User already exists");
        }
    }

    public User updateUser(User user) {
        if (userRepository.existsById(user.getUserId())) {
            return userRepository.save(user);
        } else {
            return addUser(user);
        }
    }

    public void deleteUser(Integer userId) {
        if (userRepository.existsById(userId)) {
            userRepository.deleteById(userId);
        }

    }

}
