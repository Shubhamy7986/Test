package com.emeritus.user.repository;

import com.emeritus.user.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

    List<User> findByUserType(String userType);

    User findByUserName(String userName);

    User findByUserEmail(String userEmail);

    boolean existsByUserEmail(String userEmail);

}
