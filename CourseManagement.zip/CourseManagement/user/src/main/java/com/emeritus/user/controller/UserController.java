package com.emeritus.user.controller;

import com.emeritus.user.exception.UserException;
import com.emeritus.user.model.User;
import com.emeritus.user.model.UserType;
import com.emeritus.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class UserController {

    @Autowired
    UserService userService;

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/user/{userId}")
    public Optional<User> getUser(@PathVariable Integer userId) {
        return userService.getUser(userId);
    }

    @GetMapping("/users/{userId}")
    public List<User> getUsersOfTypeStudent(@PathVariable Integer userId) {
        return userService.getAllUsersOfTypeStudent(userId);
    }

    @PostMapping("/user")
    public User addUser(@RequestBody User user) {
        if (null != user) {
            if (user.getUserType().equalsIgnoreCase(String.valueOf(UserType.Instructor)) ||
                    user.getUserType().equalsIgnoreCase(String.valueOf(UserType.System_Admin)) ||
                    user.getUserType().equalsIgnoreCase(String.valueOf(UserType.Student))) {
                return userService.addUser(user);
            }else {
                throw new UserException("Please enter valid user type : System_Admin|Instructor|Student");
            }
        }else {
            throw new UserException("User cannot be null");
        }
    }

    @PutMapping("/user")
    public User updateUser(@RequestBody User user) {
        if (null != user) {
            return userService.updateUser(user);
        }else{
            throw new UserException("User cannot be null");
        }
    }

    @DeleteMapping("/user/{userId}")
    public void deleteUser(@PathVariable Integer userId) {
        if (null != userId) {
            userService.deleteUser(userId);
        }

    }

}
