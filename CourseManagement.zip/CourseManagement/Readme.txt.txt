1.Services created -
User
Course
Enrollment
Assignment
Service-Discovery

2.To build and run the services - Open in IDE and run command (mvn clean install spring-boot:run) on terminal

3. Run all the services parallely 
Note - First run service-discovery service then other services.

4.Swagger has been implemented to access the REST api operations of all service created.
Note - Run this url in browser(http://localhost:portnumer of service/swagger-ui.html) e.g-http://localhost:8081/swagger-ui.html
portnumber on which service is running can be found in application.properties of particuler service.

5.To access H2 database of particular service goto ((http://localhost:portnumer of service/h2-console)) e.g-e.g-http://localhost:8081/swagger-ui.html
Note -Database url,username and password can be found in application.properties of particuler service.

6.To check whether all services are up goto eureka server (http://localhost:8761)
