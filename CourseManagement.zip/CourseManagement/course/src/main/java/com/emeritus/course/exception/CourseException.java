package com.emeritus.course.exception;

public class CourseException extends RuntimeException{

    public CourseException(String message){
        super(message);
    }

    public CourseException() {

    }
}