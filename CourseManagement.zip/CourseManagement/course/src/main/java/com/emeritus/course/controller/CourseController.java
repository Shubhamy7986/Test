package com.emeritus.course.controller;

import com.emeritus.course.exception.CourseException;
import com.emeritus.course.model.Course;
import com.emeritus.course.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class CourseController {

    @Autowired
    CourseService courseService;

    @GetMapping("/courses")
    public List<Course> getCourses() {
        return courseService.getCourses();
    }

    @GetMapping("/course/{courseId}")
    public Optional<Course> getCourse(@PathVariable Integer courseId) {
        return courseService.getCourse(courseId);
    }

    @PostMapping("/course/{userId}")
    public Course addCourse(@RequestBody Course course, @PathVariable Integer userId) {
        if (null != course && null != userId) {
            return courseService.addCourse(course, userId);
        }else{
            throw new CourseException("Course or userId cannot be null");
        }
    }

    @PutMapping("/course/{userId}")
    public Course updateCourse(@RequestBody Course course, @PathVariable Integer userId) {
        if (null != course && null != userId) {
            return courseService.updateCourse(course, userId);
        }else{
            throw new CourseException("Course or userId cannot be null");
        }

    }

    @DeleteMapping("/course/{courseId}/{userId}")
    public void deleteCourse(@PathVariable Integer courseId, @PathVariable Integer userId) {
        if (null != courseId && null != userId) {
            courseService.deleteCourse(courseId, userId);
        }

    }


}
