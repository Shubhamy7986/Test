package com.emeritus.course.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "courses")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Course {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "course_id")
    private Integer courseId;

    @Column(name = "course_name", nullable = false)
    @NotBlank(message = "Course name must not be blank")
    private String courseName;

    @Column(name = "created_by", nullable = false)
    @Email(message = "Please provide a vaild email address ")
    @NotBlank(message = "CreatedBy must not be blank")
    private String createdBy;


}
