package com.emeritus.course.service;

import com.emeritus.course.exception.CourseException;
import com.emeritus.course.model.Course;
import com.emeritus.course.model.User;
import com.emeritus.course.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    @Autowired
    CourseRepository courseRepository;

    @Autowired
    RestTemplate restTemplate;

    public List<Course> getCourses() {
        return (List<Course>) courseRepository.findAll();
    }

    public Optional<Course> getCourse(Integer courseId) {
        return courseRepository.findById(courseId);
    }

    public Course addCourse(Course course, Integer userId) {
        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);
        if (null != user) {
            if (user.getUserType().equals("Instructor")) {
                return courseRepository.save(course);
            }else {
                throw new CourseException("User do not have required permission");
            }
        }else {
            throw new CourseException("User not present for given userId");
        }

    }

    public Course updateCourse(Course course, Integer userId) {
        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);
        if (null != user) {
            if (user.getUserType().equals("Instructor") && courseRepository.existsById(course.getCourseId()) && user.getUserEmail().equals(course.getCreatedBy())) {
                return courseRepository.save(course);
            }else {
                throw new CourseException("User do not have required permission");
            }
        }else {
            throw new CourseException("User not present for given userId");
        }
    }


    public void deleteCourse(Integer courseId, Integer userId) {
        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);
        Optional<Course> course = courseRepository.findById(courseId);
        if (null != user && user.getUserType().equals("Instructor") && course.isPresent()) {
            if (courseRepository.existsById(courseId) && course.get().getCreatedBy().equals(user.getUserEmail())) {
                courseRepository.deleteById(courseId);
            }
        }else {
            throw new CourseException("User is not present or User does not have permission or Course is not present");
        }
    }

}
