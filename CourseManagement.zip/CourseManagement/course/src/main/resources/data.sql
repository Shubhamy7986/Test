insert into courses (course_name,created_by) values('Java','ritesh@gmail.com');
insert into courses (course_name,created_by) values('Python','ritesh@gmail.com');