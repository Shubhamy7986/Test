package com.emeritus.course;

import com.emeritus.course.model.Course;
import com.emeritus.course.service.CourseService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
class CourseApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CourseService courseService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void givenCourseObject_whenCreateCourse_thenReturnSavedCourse() throws Exception {

        Integer courseId = 1;
        Integer userId = 1;

        // given - precondition or setup/
        Course course = Course.builder()
                .courseId(courseId)
                .courseName("Java")
                .createdBy("testname@gmail.com")
                .build();

        given(courseService.addCourse(course, userId))
                .willAnswer((invocation) -> invocation.getArgument(0));

        // when - action or behaviour that we are going test
        ResultActions response = mockMvc.perform(post("/course/{userId}", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(course)));

        // then - verify the result or output using assert statements
        response.andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.courseName",
                        is(course.getCourseName())))
                .andExpect(jsonPath("$.createdBy",
                        is(course.getCreatedBy())));

    }


    @Test
    public void givenListOfCourses_whenGetAllCourses_thenReturnCoursesList() throws Exception {
        // given - precondition or setup
        List<Course> listofCourses = new ArrayList<>();
        listofCourses.add(Course.builder().courseId(1).courseName("Java").createdBy("testname@gmail.com").build());
        listofCourses.add(Course.builder().courseId(2).courseName("Python").createdBy("testname@gmail.com").build());
        given(courseService.getCourses()).willReturn(listofCourses);

        // when -  action or the behaviour that we are going test
        ResultActions response = mockMvc.perform(get("/courses"));

        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print())
                .andExpect(jsonPath("$.size()",
                        is(listofCourses.size())));

    }


    @Test
    public void givenCourseId_whenGetCourseById_thenReturnCourseObject() throws Exception {
        // given - precondition or setup
        Integer courseId = 1;
        Course course = Course.builder()
                .courseId(courseId)
                .courseName("Java")
                .createdBy("testname@gmail.com")
                .build();
        given(courseService.getCourse(1)).willReturn(Optional.of(course));

        // when -  action or the behaviour that we are going test
        ResultActions response = mockMvc.perform(get("/course/{courseId}", courseId));

        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print())
                .andExpect(jsonPath("$.courseName",
                        is(course.getCourseName())))
                .andExpect(jsonPath("$.createdBy",
                        is(course.getCreatedBy())));

    }

    @Test
    public void givenCourseId_whenDeleteCourse_thenReturn200() throws Exception {
        // given - precondition or setup
        Integer courseId = 1;
        Integer userId = 1;
        willDoNothing().given(courseService).deleteCourse(courseId, userId);

        // when -  action or the behaviour that we are going test
        ResultActions response = mockMvc.perform(delete("/course/{courseId}/{userId}", courseId, userId));

        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print());
    }

}
