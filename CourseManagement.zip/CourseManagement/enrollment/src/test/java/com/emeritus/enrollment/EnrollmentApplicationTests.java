package com.emeritus.enrollment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrollmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
