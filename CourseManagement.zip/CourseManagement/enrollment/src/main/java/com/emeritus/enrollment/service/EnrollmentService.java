package com.emeritus.enrollment.service;

import com.emeritus.enrollment.exception.EnrollmentException;
import com.emeritus.enrollment.model.Course;
import com.emeritus.enrollment.model.Enrollment;
import com.emeritus.enrollment.model.User;
import com.emeritus.enrollment.repository.EnrollmentRepository;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class EnrollmentService {

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    EnrollmentRepository enrollmentRepository;


    public void enrollCourse(Integer userId, Integer courseId) {

        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);

        Course course = restTemplate.getForObject("http://courseservice/course/{courseId}", Course.class, courseId);

        Enrollment enrollment;

        if (null != user && user.getUserType().equals("Student") && null != course ) {
            if(!enrollmentRepository.existsByCourseIdAndUserId(courseId,userId)) {
                enrollment = Enrollment.builder().userId(userId).courseId(courseId).build();
                enrollmentRepository.save(enrollment);
            }else {
                throw new EnrollmentException("User already enrolled to course");
            }

        } else {
            throw new EnrollmentException("User cannot be enrolled to course");
        }

    }

    public List<Course> getEnrolledCoursesByUserId(Integer userId) {

        List<Enrollment> enrollments = enrollmentRepository.findAllByUserId(userId);

        if (null != enrollments) {
            List<Integer> courseIds = enrollments.stream().map(Enrollment::getCourseId).collect(Collectors.toList());

            List<Course> coursesList = new ArrayList<>();
            for (Integer courseId : courseIds) {
                Course course = restTemplate.getForObject("http://courseservice/course/{courseId}", Course.class, courseId);
                coursesList.add(course);
            }

            return coursesList;
        } else {
            throw new EnrollmentException("User not enrolled in any course");
        }
    }

    public List<User> getEnrolledUsersByCourseId(Integer courseId, Integer userId) {

        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);

        if (user != null && (user.getUserType().equals("Instructor") || user.getUserType().equals("System_Admin"))) {
            List<Enrollment> enrollments = enrollmentRepository.findAllByCourseId(courseId);

            List<Integer> userIds = enrollments.stream().filter(i -> i.getCourseId().equals(courseId)).map(Enrollment::getUserId).collect(Collectors.toList());

            List<User> usersList = new ArrayList<>();
            for (Integer userIdEnrolled : userIds) {
                User userEnrolled = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userIdEnrolled);
                usersList.add(userEnrolled);
            }

            return usersList;
        } else {
            throw new EnrollmentException("User not enrolled in course or does not have permission to access course students");
        }
    }

    public Enrollment getEnrollmentByCourseIdAndUserId(Integer courseId, Integer userId) {
        if (enrollmentRepository.existsByCourseIdAndUserId(courseId, userId)) {
            return enrollmentRepository.findByCourseIdAndUserId(courseId, userId);
        }
        return null;
    }

}
