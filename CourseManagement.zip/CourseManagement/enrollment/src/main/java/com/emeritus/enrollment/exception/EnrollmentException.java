package com.emeritus.enrollment.exception;

public class EnrollmentException extends RuntimeException {

    public EnrollmentException(String message) {
        super(message);
    }

    public EnrollmentException() {

    }

}
