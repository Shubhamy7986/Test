package com.emeritus.enrollment.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "enrollments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Enrollment {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name="enrollment_id")
    private Integer enrollmentId;

    @Column(name="user_id")
    @NotNull(message = "User Id cannot be null")
    private Integer userId;

    @Column(name="course_id")
    @NotNull(message = "Course Id must not be blank")
    private Integer courseId;


}
