package com.emeritus.enrollment.controller;

import com.emeritus.enrollment.exception.EnrollmentException;
import com.emeritus.enrollment.model.Course;
import com.emeritus.enrollment.model.Enrollment;
import com.emeritus.enrollment.model.User;
import com.emeritus.enrollment.service.EnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class EnrollmentController {

    @Autowired
    EnrollmentService enrollmentService;


    @GetMapping("/enrolledcourses/{userId}")
    public List<Course> getEnrolledCoursesByUserId(@PathVariable Integer userId) {
        if (null != userId) {
            return enrollmentService.getEnrolledCoursesByUserId(userId);
        } else {
            throw new EnrollmentException("userId cannot be added");
        }

    }


    @GetMapping("/enrolledusers/{courseId}/{userId}")
    public List<User> getEnrolledUsersByCourseId(@PathVariable Integer courseId, @PathVariable Integer userId) {
        if (null != courseId && null != userId) {
            return enrollmentService.getEnrolledUsersByCourseId(courseId, userId);
        } else {
            throw new EnrollmentException("courseId  or userId cannot be added");
        }

    }

    @GetMapping("/enrollment/{courseId}/{userId}")
    public Enrollment getEnrollmentByCourseIdAndUserId(@PathVariable Integer courseId, @PathVariable Integer userId) {
        if (null != userId) {
            return enrollmentService.getEnrollmentByCourseIdAndUserId(courseId, userId);
        } else {
            throw new EnrollmentException("userId cannot be added");
        }

    }

    @PostMapping("/enroll/{userId}/{courseId}")
    public void enrollCourse(@PathVariable Integer userId, @PathVariable Integer courseId) {
        if (userId != null && courseId != null) {
            enrollmentService.enrollCourse(userId, courseId);
        }
    }


}
