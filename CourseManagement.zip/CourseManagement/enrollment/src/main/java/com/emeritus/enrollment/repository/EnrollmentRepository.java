package com.emeritus.enrollment.repository;

import com.emeritus.enrollment.model.Enrollment;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EnrollmentRepository extends CrudRepository<Enrollment, Integer> {

    List<Enrollment> findAllByUserId(Integer userId);

    List<Enrollment> findAllByCourseId(Integer courseId);

    boolean existsByCourseIdAndUserId(Integer courseId, Integer userId);

    Enrollment findByCourseIdAndUserId(Integer courseId, Integer userId);

}
