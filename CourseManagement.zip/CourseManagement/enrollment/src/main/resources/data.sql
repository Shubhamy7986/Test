insert into enrollments (course_id, user_id) values (1,3);
insert into enrollments (course_id, user_id) values (2,3);