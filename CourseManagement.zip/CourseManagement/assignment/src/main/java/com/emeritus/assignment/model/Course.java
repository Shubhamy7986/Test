package com.emeritus.assignment.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Course {

    private Integer courseId;

    private String courseName;

    private String createdBy;

}
