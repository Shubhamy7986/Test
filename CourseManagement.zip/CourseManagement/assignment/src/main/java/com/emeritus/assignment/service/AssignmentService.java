package com.emeritus.assignment.service;

import com.emeritus.assignment.exception.AssignmentException;
import com.emeritus.assignment.model.Assignment;
import com.emeritus.assignment.model.Course;
import com.emeritus.assignment.model.Enrollment;
import com.emeritus.assignment.model.User;
import com.emeritus.assignment.repository.AssignmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class AssignmentService {

    @Autowired
    AssignmentRepository assignmentRepository;

    @Autowired
    RestTemplate restTemplate;

    public Optional<Assignment> getAssignmentByAssignemntId(Integer assignmentId, Integer userId) {
        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);

        if (null != user && user.getUserType().equals("Instructor")) {
            if (assignmentRepository.existsById(assignmentId)) {
                return assignmentRepository.findById(assignmentId);
            }
        }
        return Optional.empty();
    }

    public List<Assignment> getAssignmentsOfEnrolledCourse(Integer courseId, Integer userId) {
        Enrollment enrollment = restTemplate.getForObject("http://enrollmentservice//enrollment/{courseId}/{userId}", Enrollment.class, courseId, userId);

        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);

        Course course = restTemplate.getForObject("http://courseservice/course/{courseId}", Course.class, courseId);

        if (null != enrollment) {
            if (null != user && user.getUserType().equals("Student")) {
                return assignmentRepository.findByCourseId(courseId);
            } else {
                throw new AssignmentException("User cannot be null or does not have required permission");
            }
        } else {
            throw new AssignmentException("User not enrolled for this course");
        }

    }

    public Assignment addAssignment(Assignment assignment, Integer userId) {

        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);

        Course course = restTemplate.getForObject("http://courseservice/course/{courseId}", Course.class, assignment.getCourseId());

        if (null != user && user.getUserType().equals("Instructor") && course != null && user.getUserEmail().equals(course.getCreatedBy())) {
            return assignmentRepository.save(assignment);
        } else {
            throw new AssignmentException("Assignment cannot be added");
        }

    }

    public Assignment updateAssignment(Assignment assignment, Integer userId) {

        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);

        if (null != user && user.getUserType().equals("Instructor") && user.getUserEmail().equals(assignment.getCreatedBy())) {
            if (assignmentRepository.existsById(assignment.getAssignmentId())) {
                return assignmentRepository.save(assignment);
            } else {
                throw new AssignmentException("Assignment does not exist");
            }
        } else {
            throw new AssignmentException("Assignment cannot be updated");
        }
    }

    public void deleteAssignment(Integer assignmentId, Integer userId) {
        User user = restTemplate.getForObject("http://userservice/user/{userId}", User.class, userId);

        Optional<Assignment> assignment = assignmentRepository.findById(assignmentId);

        if (null != user && user.getUserType().equals("Instructor") && assignment.isPresent() && user.getUserEmail().equals(assignment.get().getCreatedBy())) {
            if (assignmentRepository.existsById(assignmentId)) {
                assignmentRepository.deleteById(assignmentId);
            }
        }
    }


}
