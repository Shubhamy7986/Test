package com.emeritus.assignment.controller;

import com.emeritus.assignment.exception.AssignmentException;
import com.emeritus.assignment.model.Assignment;
import com.emeritus.assignment.service.AssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class AssignmentController {

    @Autowired
    AssignmentService assignmentService;

    @GetMapping("/assignment/{assignemntId}/{userId}")
    public Optional<Assignment> getAssignmentByAssignmentId(Integer assignmentId, Integer userId) {
        return assignmentService.getAssignmentByAssignemntId(assignmentId, userId);
    }

    @GetMapping("/assignments/{courseId}/{userId}")
    public List<Assignment> getAssignmentsOfEnrolledCourse(@PathVariable Integer courseId, @PathVariable Integer userId) {
        if (null != courseId && null != userId) {
            return assignmentService.getAssignmentsOfEnrolledCourse(courseId, userId);
        } else {
            throw new AssignmentException("courseId or userId cannot be null");
        }

    }

    @PostMapping("/assignment/{userId}")
    public Assignment addAssignment(@RequestBody Assignment assignment, @PathVariable Integer userId) {
        if (null != assignment && null != userId) {
            return assignmentService.addAssignment(assignment, userId);
        } else {
            throw new AssignmentException("Assignment or userId cannot be null");
        }

    }

    @PutMapping("/assignment/{assignmentId}/{userId}")
    public Assignment updateAssignment(@RequestBody Assignment assignment, @PathVariable Integer userId) {
        if (null != assignment && null != userId) {
            return assignmentService.updateAssignment(assignment, userId);
        }
        return null;
    }

    @DeleteMapping("/assignment/{assignmentId}/{userId}")
    public void deleteAssignment(@PathVariable Integer assignmentId, @PathVariable Integer userId) {
        if (null != assignmentId && null != userId) {
            assignmentService.deleteAssignment(assignmentId, userId);
        }
    }

}
