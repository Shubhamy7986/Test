package com.emeritus.assignment.exception;

public class AssignmentException extends RuntimeException{

    public AssignmentException(String message){
        super(message);
    }

    public AssignmentException() {

    }

}
