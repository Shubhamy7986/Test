package com.emeritus.assignment.repository;

import com.emeritus.assignment.model.Assignment;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface AssignmentRepository extends CrudRepository<Assignment,Integer> {

    Assignment findByAssignmentDescription(String assignmentDescription);

    List<Assignment> findByCourseId(Integer courseId);

}
