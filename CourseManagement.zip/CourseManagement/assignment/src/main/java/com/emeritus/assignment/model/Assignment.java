package com.emeritus.assignment.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "assignments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Assignment {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "assignment_id")
    private Integer assignmentId;

    @Column(name = "course_id", nullable = false)
    @NotNull
    private Integer courseId;

    @Column(name = "assignment_description", nullable = false)
    @NotBlank(message = "Assignment Description must not be blank")
    private String assignmentDescription;

    @Column(name = "created_by", nullable = false)
    @Email(message = "Please provide a vaild email address ")
    @NotBlank(message = "Created By must not be blank")
    private String createdBy;

}
