package com.emeritus.assignment.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Enrollment {

    private Integer enrollmentId;

    private Integer userId;

    private Integer courseId;


}