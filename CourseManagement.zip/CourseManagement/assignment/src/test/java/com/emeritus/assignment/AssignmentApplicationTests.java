package com.emeritus.assignment;

import com.emeritus.assignment.model.Assignment;
import com.emeritus.assignment.repository.AssignmentRepository;
import com.emeritus.assignment.service.AssignmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
class AssignmentApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AssignmentService assignmentService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void givenAssignmentObject_whenCreateAssignment_thenReturnSavedAssignment() throws Exception {

        Integer userId = 1;

        // given - precondition or setup/
        Assignment assignment = Assignment.builder()
                .courseId(1)
                .assignmentDescription("Write Java 8 features with example")
                .createdBy("testname@gmail.com")
                .build();

        given(assignmentService.addAssignment(assignment,userId))
                .willAnswer((invocation) -> invocation.getArgument(0));

        // when - action or behaviour that we are going test
        ResultActions response = mockMvc.perform(post("/assignment/{userId}", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(assignment)));

        // then - verify the result or output using assert statements
        response.andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.assignmentDescription",
                        is(assignment.getAssignmentDescription())))
                .andExpect(jsonPath("$.createdBy",
                        is(assignment.getCreatedBy())));

    }




    @Test
    public void givenAssignmetId_whenDeleteAssignment_thenReturn200() throws Exception {
        // given - precondition or setup
        Integer assignmentId = 1;
        Integer userId = 1;
        willDoNothing().given(assignmentService).deleteAssignment(assignmentId, userId);

        // when -  action or the behaviour that we are going test
        ResultActions response = mockMvc.perform(delete("/assignment/{assignmentId}/{userId}", assignmentId, userId));

        // then - verify the output
        response.andExpect(status().isOk())
                .andDo(print());
    }

}
